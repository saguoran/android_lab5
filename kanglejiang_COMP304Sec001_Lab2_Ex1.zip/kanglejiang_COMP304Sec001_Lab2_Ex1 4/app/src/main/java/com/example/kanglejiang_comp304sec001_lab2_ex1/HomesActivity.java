package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.stream.Collectors;

import static com.example.kanglejiang_comp304sec001_lab2_ex1.HomeTypeActivity.HOME_TYPE;

public class HomesActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homes);
        findViewById(R.id.button2).setOnClickListener(v -> {
            Intent intent = new Intent(this, CheckoutActivity.class);
            HomesActivity.this.startActivity(intent);
        });
        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        HomeType homeType = (HomeType) intent.getSerializableExtra(HOME_TYPE);
        ArrayList<Home> homes = Home.allHomes().stream().filter(x -> x.homeType == homeType)
                .collect(Collectors.toCollection(ArrayList::new));
        HomeAdapter adapter = new HomeAdapter(this, homes);
// Attach the adapter to a ListView
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_type, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        return handleSelection(item);
    }
    private boolean handleSelection(MenuItem item){
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.apartment:
                updateScreen(HomeType.APARTMENT);
                return true;
            case R.id.detached_home:
                updateScreen(HomeType.DETACHED_HOME);
                return true;
            case R.id.semi_detached_home:
                updateScreen(HomeType.SEMI_DETACHED_HOME);
                return true;
            case R.id.condominium:
                updateScreen(HomeType.CONDOMINIUM);
                return true;
            case R.id.town_house:
                updateScreen(HomeType.TOWN_HOUSE);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateScreen(HomeType t)
    {
        ArrayList<Home> homes = Home.allHomes().stream().filter(x -> x.homeType ==  t)
                .collect(Collectors.toCollection(ArrayList::new));
        HomeAdapter adapter = new HomeAdapter(HomesActivity.this, homes);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.clearChoices();
        listView.setAdapter(adapter);
    }

}