package com.example.kanglejiang_comp304sec001_lab2_ex1;

public enum HomeType {
    APARTMENT,
    DETACHED_HOME,
    SEMI_DETACHED_HOME,
    CONDOMINIUM,
    TOWN_HOUSE,
}
