package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.button).setOnClickListener(v -> {
            PreferenceManager.getDefaultSharedPreferences(MainActivity.this).edit().clear().apply();
            Intent intent = new Intent(MainActivity.this, HomeTypeActivity.class);
            MainActivity.this.startActivity(intent);
        });
    }
}