package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class PayMethodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_method);
        findViewById(R.id.pay_button).setOnClickListener(v -> {
            Intent intent = new Intent(PayMethodActivity.this, CardInfoActivity.class);
            PayMethodActivity.this.startActivity(intent);
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radio_cash:
                if (checked)
                    findViewById(R.id.pay_button).setVisibility(View.GONE);
                break;
            case R.id.radio_credit:
                if (checked)
                    findViewById(R.id.pay_button).setVisibility(View.VISIBLE);
                break;
            case R.id.radio_debit:
                if (checked)
                    findViewById(R.id.pay_button).setVisibility(View.VISIBLE);
                break;
        }
    }
}