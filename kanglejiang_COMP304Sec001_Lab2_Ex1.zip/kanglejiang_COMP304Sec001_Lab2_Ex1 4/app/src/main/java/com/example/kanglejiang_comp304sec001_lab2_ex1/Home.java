package com.example.kanglejiang_comp304sec001_lab2_ex1;

import java.util.ArrayList;

public class Home {
    public HomeType homeType;
    public String address;
    public int image;
    public float price;

    public Home(HomeType homeType, String address, int image, float price) {
        this.homeType = homeType;
        this.address = address;
        this.image = image;
        this.price = price;
    }
    private static ArrayList<Home> allHomes;
    public static ArrayList<Home> allHomes(){
        if(allHomes!=null) return allHomes;
        allHomes = new ArrayList<Home>();
// Create the adapter to convert the array to views
        allHomes.add(new Home(HomeType.APARTMENT, "321 Progress Ave. Scarborough Toronto", R.drawable.apartment1, 1000));
        allHomes.add(new Home(HomeType.APARTMENT, "322 Progress Ave. Scarborough Toronto", R.drawable.apartment2, 1000));


        allHomes.add(new Home(HomeType.DETACHED_HOME, "321 Shadow Ave. Scarborough Toronto", R.drawable.detached_house1, 2000));
        allHomes.add(new Home(HomeType.DETACHED_HOME, "322 Shadow Ave. Scarborough Toronto", R.drawable.detached_house2, 2000));

        allHomes.add(new Home(HomeType.SEMI_DETACHED_HOME, "321 Darkness Ave. Scarborough Toronto", R.drawable.semi_detached_house1, 1030));
        allHomes.add(new Home(HomeType.SEMI_DETACHED_HOME, "322 Darkness Ave. Scarborough Toronto", R.drawable.semi_detached_house2, 1090));

        allHomes.add(new Home(HomeType.CONDOMINIUM, "321 Seems Ave. Scarborough Toronto", R.drawable.condominium1, 800));
        allHomes.add(new Home(HomeType.CONDOMINIUM, "322 Seems Ave. Scarborough Toronto", R.drawable.condominium2, 900));

        allHomes.add(new Home(HomeType.TOWN_HOUSE, "321 Jakusha Ave. Scarborough Toronto", R.drawable.town_house1, 1000));
        allHomes.add(new Home(HomeType.TOWN_HOUSE, "322 Jakusha Ave. Scarborough Toronto", R.drawable.town_house2, 1000));
        return allHomes;
    }
}
