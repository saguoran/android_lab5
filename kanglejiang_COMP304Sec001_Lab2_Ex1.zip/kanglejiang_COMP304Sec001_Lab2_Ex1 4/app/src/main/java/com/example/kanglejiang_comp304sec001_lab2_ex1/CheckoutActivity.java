package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

public class CheckoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        // Get the Intent that started this activity and extract the string
        Map<String, ?> selectionHomes = PreferenceManager.getDefaultSharedPreferences(CheckoutActivity.this).getAll();
        ArrayList<Home> homes = Home.allHomes().stream().filter(x -> selectionHomes.containsKey(x.address))
                .collect(Collectors.toCollection(ArrayList::new));
        HomeAdapter2 adapter = new HomeAdapter2(this, homes);
// Attach the adapter to a ListView
        ListView listView = (ListView) findViewById(R.id.checkout_list);
        listView.setAdapter(adapter);
        findViewById(R.id.button3).setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, PayMethodActivity.class);
            startActivity(intent);
        });
    }


}