package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeTypeActivity extends AppCompatActivity {

//  apartment
//  detached home
//  semi-detached home
//  condominium
//  town house

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_type);
        TextView textView = (TextView) findViewById(R.id.textView);
        //this view is associated with context menu
        //if you do a long click here, the context menu
        //will be displayed.
        registerForContextMenu(textView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_type, menu);
        return true;
    }
    public static final String HOME_TYPE = "HOME_TYPE";

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return handleSelection(item);
    }

    //
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        return handleSelection(item);
    }

    //
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_type, menu);
    }
    private boolean handleSelection(MenuItem item){
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.apartment:
                Intent intent = new Intent(this, HomesActivity.class);
                intent.putExtra(HOME_TYPE, HomeType.APARTMENT);
                startActivity(intent);
                return true;
            case R.id.detached_home:
                intent = new Intent(this, HomesActivity.class);
                intent.putExtra(HOME_TYPE, HomeType.DETACHED_HOME);
                startActivity(intent);
                return true;
            case R.id.semi_detached_home:
                intent = new Intent(this, HomesActivity.class);
                intent.putExtra(HOME_TYPE, HomeType.SEMI_DETACHED_HOME);
                startActivity(intent);
                return true;
            case R.id.condominium:
                intent = new Intent(this, HomesActivity.class);
                intent.putExtra(HOME_TYPE, HomeType.CONDOMINIUM);
                startActivity(intent);
                return true;
            case R.id.town_house:
                intent = new Intent(this, HomesActivity.class);
                intent.putExtra(HOME_TYPE, HomeType.TOWN_HOUSE);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}