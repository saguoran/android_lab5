package com.example.kanglejiang_comp304sec001_lab2_ex1;

import android.content.Context;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Map;

public class HomeAdapter2 extends ArrayAdapter<Home> {

    public HomeAdapter2(Context context, ArrayList<Home> homes) {
        super(context, 0, homes);
    }
    String tag = "Radio: ";
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Home home = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.home_selection_radio, parent, false);
        }
        CheckBox checkbox = ((CheckBox) convertView.findViewById(R.id.checkout_check_box));
        Map<String, ?> map=  PreferenceManager.getDefaultSharedPreferences(getContext()).getAll();
//        checkbox.setChecked(PreferenceManager.getDefaultSharedPreferences(getContext()).getAll().containsKey(home.address));
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
//                    add home address
                Log.d(tag,home.address);
                PreferenceManager.getDefaultSharedPreferences(getContext()).edit()
                        .putString(home.address, home.address)
                        .apply();
            } else {
//                    remove home address
                Log.d(tag,home.address);
                PreferenceManager.getDefaultSharedPreferences(getContext()).edit()
                        .remove(home.address)
                        .apply();
            }
        });
        // Lookup view for data population
        TextView address = (TextView) convertView.findViewById(R.id.address);
        TextView homeType = (TextView) convertView.findViewById(R.id.home_type);
        TextView price = (TextView) convertView.findViewById(R.id.price);
        ImageView imgView = (ImageView) convertView.findViewById(R.id.imageView3);
        // Populate the data into the template view using the data object
        address.setText(home.address);
        homeType.setText(home.homeType.toString());
        price.setText(formatDecimal(home.price));
        imgView.setImageResource(home.image);
        // Return the completed view to render on screen
        return convertView;
    }

    public String formatDecimal(float number) {
        float epsilon = 0.004f; // 4 tenths of a cent
        if (Math.abs(Math.round(number) - number) < epsilon) {
            return String.format("$%10.0f", number); // sdb
        } else {
            return String.format("$%10.2f", number); // dj_segfault
        }
    }
}