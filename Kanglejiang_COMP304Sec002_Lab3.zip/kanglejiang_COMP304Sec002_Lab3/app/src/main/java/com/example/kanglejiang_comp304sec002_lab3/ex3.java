package com.example.Kanglejiang_COMP304Sec002_Lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class ex3 extends AppCompatActivity {
    boolean playing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex3);
        ImageView earth = findViewById(R.id.imageView3);
        ImageView moon = findViewById(R.id.imageView);
        Animation rotate = AnimationUtils.loadAnimation(this, R.anim.moon_rotate);
        Animation orbit = AnimationUtils.loadAnimation(this, R.anim.moon_orbit);
        AnimationSet s = new AnimationSet(true);//false means don't share interpolators
        s.setInterpolator(new LinearInterpolator());
        s.addAnimation(rotate);
        s.addAnimation(orbit);
        s.setAnimationListener(new Animation.AnimationListener() {
                                   @Override
                                   public void onAnimationStart(Animation animation) {
                                       playing = true;
                                   }

                                   @Override
                                   public void onAnimationEnd(Animation animation) {
                                       playing = false;
                                   }

                                   @Override
                                   public void onAnimationRepeat(Animation animation) {

                                   }
                               }
        );
        moon.setOnClickListener(view -> {
            if (playing)
                moon.clearAnimation();
            else
                moon.startAnimation(s);

        });
        earth.setOnClickListener(view -> {
            if (playing)
                moon.clearAnimation();
            else
                moon.startAnimation(s);

        });
    }
}