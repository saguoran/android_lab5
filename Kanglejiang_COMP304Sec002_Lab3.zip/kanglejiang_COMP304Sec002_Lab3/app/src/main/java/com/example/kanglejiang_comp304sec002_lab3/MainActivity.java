package com.example.Kanglejiang_COMP304Sec002_Lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    final private String[] users = { "Exercise 1", "Exercise 2", "Exercise 3"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView mListView = findViewById(R.id.listview);
        ArrayAdapter aAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, users);
        mListView.setAdapter(aAdapter);
        mListView.setOnItemClickListener((parent, view, position, id) -> {
            if(position==0){
                Intent intent = new Intent(MainActivity.this, ex1.class);
                startActivity(intent);
            }else if(position==1){
                Intent intent = new Intent(MainActivity.this, ex2.class);
                startActivity(intent);
            }else if(position==2){
                Intent intent = new Intent(MainActivity.this, ex3.class);
                startActivity(intent);
            }
        });
    }
}