package com.example.Kanglejiang_COMP304Sec002_Lab3;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

public class MyCanvas extends View {
    public MyCanvas(Context context) {
        super(context);
    }

    public MyCanvas(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public MyCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public void drawUp(){
        if(y-velocityY<0) return;
        int y2=y-velocityY;
        canvas.drawLine(x,y,x,y2, paint);
        y= y2;
    }
    Canvas canvas;
    int x,y ;
     int velocityX=20, velocityY = 20;
    Paint paint = new Paint();
    Path path = new Path();
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(3);

        // Draw the bitmap that has the saved path.
        canvas.drawBitmap(bitmap, 0, 0, null);

    }

    private Bitmap bitmap;
    public void drawBottom(){

        int y2=y+velocityY;
        if(y2>getHeight())return;
//        path.moveTo(x,y);
//        path.quadTo(x,y,x,y2);
//        canvas.drawPath(path, paint);
        canvas.drawLine(x,y,x,y2, paint);
        y= y2;
    }

    public void drawRight() {
        int x2 = x + velocityX;
        if(x2>getWidth())return;
        canvas.drawLine(x, y, x2, y, paint);
        x=x2;
    }

    public void drawLeft(){
        int x2 = x - velocityX;
        if(x2<0)return;
        canvas.drawLine(x, y, x2, y, paint);
        x=x2;
    }
    public void setPaintStrokeWidth(int width){
        this.paint.setStrokeWidth(width);
    }
    public void createCanvas(){
        int w = getWidth(), h = getHeight();
        Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
        Bitmap bmp = Bitmap.createBitmap(w, h, conf); // this creates a MUTABLE bitmap
        this.canvas = new Canvas(bmp);
    }

    /**
     * Note: Called whenever the view changes size.
     * Since the view starts out with no size, this is also called after
     * the view has been inflated and has a valid size.
     */
    @Override
    protected void onSizeChanged(int width, int height,
                                 int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        // Create bitmap, create canvas with bitmap, fill canvas with color.
        bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
    }
}
