package com.example.Kanglejiang_COMP304Sec002_Lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;

public class ex2 extends AppCompatActivity {
    AnimationDrawable animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex2);
        ImageView image =  findViewById(R.id.imageView);
        image.setBackgroundResource(R.drawable.wizard_run);
        animation = (AnimationDrawable) image.getBackground();
        image.setOnClickListener(view -> {
            if(animation.isRunning())
                animation.stop();
            else
            animation.start();
        });
    }
}