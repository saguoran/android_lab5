package com.example.Kanglejiang_COMP304Sec002_Lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;

public class ex1 extends AppCompatActivity {
    Path path = new Path();
    MyCanvas myCanvas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ex1);
        myCanvas = findViewById(R.id.my_canvas);
        ImageButton up = findViewById(R.id.up_btn);
        ImageButton bottom = findViewById(R.id.bottom_btn);
        ImageButton right = findViewById(R.id.right_btn);
        ImageButton left = findViewById(R.id.left_btn);
        bottom.setOnTouchListener(new RepeatListener(400, 100, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myCanvas.drawBottom();
            }
        }));
        right.setOnTouchListener(new RepeatListener(200, 100, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myCanvas.drawRight();
            }
        }));
        up.setOnTouchListener(new RepeatListener(200, 100, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myCanvas.drawUp();
            }
        }));
        left.setOnTouchListener(new RepeatListener(200, 100, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myCanvas.drawLeft();
            }
        }));
        Spinner widthSpinner = (Spinner) findViewById(R.id.width_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.stoke_width, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        widthSpinner.setAdapter(adapter);
        widthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0)
                    myCanvas.paint.setStrokeWidth(3);
                else if(position==1)
                    myCanvas.paint.setStrokeWidth(7);
                else if(position==2)
                    myCanvas.paint.setStrokeWidth(16);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

//        paint.setColor(color);
        Spinner colorSpinner = (Spinner) findViewById(R.id.color_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.stoke_color, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        colorSpinner.setAdapter(adapter1);
        colorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0)
                    myCanvas.paint.setColor(Color.BLACK);
                else if(position==1)
                    myCanvas.paint.setColor(Color.RED);
                else if(position==2)
                    myCanvas.paint.setColor(Color.BLUE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    /**
     * A class, that can be used as a TouchListener on any view (e.g. a Button).
     * It cyclically runs a clickListener, emulating keyboard-like behaviour. First
     * click is fired immediately, next one after the initialInterval, and subsequent
     * ones after the normalInterval.
     *
     * <p>Interval is scheduled after the onClick completes, so it has to run fast.
     * If it runs slow, it does not generate skipped onClicks. Can be rewritten to
     * achieve this.
     */
    public class RepeatListener implements View.OnTouchListener {

        private Handler handler = new Handler();

        private int initialInterval;
        private final int normalInterval;
        private final View.OnClickListener clickListener;
        private View touchedView;

        private Runnable handlerRunnable = new Runnable() {
            @Override
            public void run() {
                if(touchedView.isEnabled()) {
                    handler.postDelayed(this, normalInterval);
                    clickListener.onClick(touchedView);
                } else {
                    // if the view was disabled by the clickListener, remove the callback
                    handler.removeCallbacks(handlerRunnable);
                    touchedView.setPressed(false);
                    touchedView = null;
                }
            }
        };

        /**
         * @param initialInterval The interval after first click event
         * @param normalInterval The interval after second and subsequent click
         *       events
         * @param clickListener The OnClickListener, that will be called
         *       periodically
         */
        public RepeatListener(int initialInterval, int normalInterval,
                              View.OnClickListener clickListener) {
            if (clickListener == null)
                throw new IllegalArgumentException("null runnable");
            if (initialInterval < 0 || normalInterval < 0)
                throw new IllegalArgumentException("negative interval");

            this.initialInterval = initialInterval;
            this.normalInterval = normalInterval;
            this.clickListener = clickListener;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    handler.removeCallbacks(handlerRunnable);
                    handler.postDelayed(handlerRunnable, initialInterval);
                    touchedView = view;
                    touchedView.setPressed(true);
                    clickListener.onClick(view);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(handlerRunnable);
                    touchedView.setPressed(false);
                    touchedView = null;
                    return true;
            }

            return false;
        }

    }
}