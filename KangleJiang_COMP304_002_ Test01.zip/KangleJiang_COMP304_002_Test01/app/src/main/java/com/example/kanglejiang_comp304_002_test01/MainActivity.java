package com.example.kanglejiang_comp304_002_test01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CheckBox;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public final static String STOCKS = "stocks";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.button).setOnClickListener(x -> {
            final ArrayList<String> checkedList = new ArrayList<>();
            if (((CheckBox) findViewById(R.id.ibm_checkbox)).isChecked())
                checkedList.add(getResources().getString(R.string.ibm));
            if (((CheckBox) findViewById(R.id.goog_checkbox)).isChecked())
                checkedList.add(getResources().getString(R.string.goog));
            if (((CheckBox) findViewById(R.id.msft_checkbox)).isChecked())
                checkedList.add(getResources().getString(R.string.msft));
            if (((CheckBox) findViewById(R.id.appl_checkbox)).isChecked())
                checkedList.add(getResources().getString(R.string.appl));
            if (((CheckBox) findViewById(R.id.orcl_checkbox)).isChecked())
                checkedList.add(getResources().getString(R.string.orcl));
            Intent intent = new Intent(MainActivity.this, StockPriceActivity.class);
            intent.putExtra(STOCKS, checkedList);
            startActivity(intent);
        });
    }
}