package com.example.kanglejiang_comp304_002_test01;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Canvas;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.SYSTEM_UI_FLAG_FULLSCREEN;

public class StockPriceActivity extends AppCompatActivity {
    final int xDistance = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_price);
        ArrayList<String> stocks=  (ArrayList<String>)getIntent().getSerializableExtra(MainActivity.STOCKS);
        StockChartCanvas chartCanvas = findViewById(R.id.canvas);
        chartCanvas.stocks = stocks;
        ((TextView)findViewById(R.id.chart_label)).setText("Chats: "+ String.join(", ", stocks));
    }
}