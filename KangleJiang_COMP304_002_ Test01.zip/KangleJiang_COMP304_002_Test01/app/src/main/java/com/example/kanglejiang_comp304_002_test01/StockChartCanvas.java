package com.example.kanglejiang_comp304_002_test01;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class StockChartCanvas extends View {
    public StockChartCanvas(Context context) {
        super(context);
    }

    public StockChartCanvas(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public StockChartCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public StockChartCanvas(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    private final Paint paint = new Paint();


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(3);
        paint.setTextSize(40);
//        draw y
        canvas.drawLine(0,0,0, 700,paint);
        for (int i = 100; i < 601; i+=100) {
            canvas.drawLine(0,i, 20, i, paint);
            if(i%200!=0)
            canvas.drawText(String.valueOf(700-i),25,i,paint);
        }
//        draw x
        canvas.drawLine(0,700,1000,700 ,paint);
        for (int i = 100; i < 1001; i+=100) {
                canvas.drawLine(i,700, i, 680, paint);
            if(i%200==0)
                canvas.drawText(String.valueOf(i/100), i, 680,paint);
        }
        //            draw ibm
        String text = getResources().getString(R.string.ibm);
        if(stocks.contains(text)){
            String[]stock = getResources().getStringArray(R.array.ibm);
            drawStock(canvas, stock, Color.RED, text);
        }
        /// google
        text = getResources().getString(R.string.goog);
        if(stocks.contains(text)){
            String[]stock = getResources().getStringArray(R.array.goog);
            drawStock(canvas, stock, Color.GREEN,text);
        }
        /// microsoft
        text = getResources().getString(R.string.msft);
        if(stocks.contains(text)){
            String[]stock = getResources().getStringArray(R.array.msft);
            drawStock(canvas, stock, Color.BLUE,text);
        }
        /// apple
        text = getResources().getString(R.string.appl);
        if(stocks.contains(text)){
            String[]stock = getResources().getStringArray(R.array.appl);
            drawStock(canvas, stock, Color.BLACK, text);
        }
        /// orcl
        text = getResources().getString(R.string.orcl);
        if(stocks.contains(text)){
            String[]stock = getResources().getStringArray(R.array.orcl);
            drawStock(canvas, stock, Color.parseColor("#e76f51"), text);
        }
    }
    public ArrayList<String> stocks;
    int xLabel = 750;
    private void drawStock(Canvas canvas, String[] stock, int color, String label){
        paint.setColor(color);
        int x = 0;
        for (int i = 0; i < stock.length; i++) {
            int xDistance = 100;
            if(i+1!=stock.length)
                canvas.drawLine(x, 700-Integer.parseInt(stock[i]), x+ xDistance,700-Integer.parseInt(stock[i+1]), paint);
            x+= xDistance;
        }
//        800
        canvas.drawRect(0, xLabel, 80, xLabel +30, paint);
        paint.setColor(Color.BLACK);
        canvas.drawText(label, 100, xLabel+30, paint);
        xLabel +=100;
    }
}
